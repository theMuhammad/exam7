import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";

function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
            Hi Everyone, I am <span className="purple">Muhammad Makhmudov </span>
            from <span className="purple"> Tashkent , Uzbekistan</span>
            <br />
            I`m not currently working anywhere
            <br />
            In <span className="purple">2023-2024</span> , I studied in the field of<span className="purple"> Frontend React Js</span> at<span className="purple"> Najot Education (LLC)</span>  training center in <span className="purple">Tashkent.</span>
            <br />
            <br />
            Apart from coding, some other activities that <span className="purple">I love to do!</span>
          </p>
          <ul>
            <li className="about-activity">
              <ImPointRight /> <span className="purple">Playing Games</span>
            </li>
            <li className="about-activity">
              <ImPointRight /> <span className="purple">Writing Tech Blogs</span>
            </li>
            <li className="about-activity">
              <ImPointRight /> <span className="purple">Travelling</span>
            </li>
            <li className="about-activity">
              <ImPointRight /> <span className="purple">Drawing pictures</span>
            </li>
          </ul>
        </blockquote>
      </Card.Body>
    </Card>
  );
}

export default AboutCard;
