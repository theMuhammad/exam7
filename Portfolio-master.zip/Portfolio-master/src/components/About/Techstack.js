import React from "react";
import { Col, Row } from "react-bootstrap";
import { SiRedux } from "react-icons/si";
import { SiMui } from "react-icons/si";
import { SiTailwindcss } from "react-icons/si";
import { FaHtml5 } from "react-icons/fa";
import { FaCss3 } from "react-icons/fa";
import { IoLogoSass } from "react-icons/io";
import { FaGithub } from "react-icons/fa";
import { FaGitAlt } from "react-icons/fa";
import {
  DiJavascript1,
  DiReact,
  DiNodejs,
} from "react-icons/di";

function Techstack() {
  return (
    <Row style={{ justifyContent: "center", paddingBottom: "50px", cursor: "pointer" }}>
      <Col xs={6} md={4} className="tech-icons">
        <FaHtml5 /> | <FaCss3 /> | <IoLogoSass />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <DiJavascript1 />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <DiNodejs />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <DiReact />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <SiRedux />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <SiMui/>
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <SiTailwindcss />
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <FaGithub/>
      </Col>
      <Col xs={4} md={2} className="tech-icons">
        <FaGitAlt />
      </Col>
    </Row>
  );
}

export default Techstack;
