

function ProjectCards() {
  return (
    <h2>I currently have real projects in <span style={{color:"#b0b0b0"}}>2024</span> and I'm working on them !</h2>
  );
}
export default ProjectCards;
